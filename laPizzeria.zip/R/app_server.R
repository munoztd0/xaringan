#' The application server-side
#' 
#' @param input,output,session Internal parameters for {shiny}. 
#'     DO NOT REMOVE.
#' @import shiny
#' @noRd
app_server <- function( input, output, session ) {
  # Your application server logic 
  
  mod_interaction_with_list_server("interaction_with_list_ui_1")

  loaded_metrics <- FALSE
  loaded_live_expo <- FALSE

  observeEvent(input$tabs, {
      if (input$tabs == "Live Watchlist Metrics" & !loaded_metrics){
        loaded_metrics <<- TRUE
        mod_real_time_client_metrics_server("real_time_client_metrics_ui_1")
      }
      if (input$tabs == "RealTime Exposure" & !loaded_live_expo){
        loaded_live_expo <<- TRUE
        mod_real_time_exposure_by_security_server("real_time_exposure_by_security_ui_1")
      }
  })
  

}
