#' The application User-Interface
#' 
#' @param request Internal parameter for `{shiny}`. 
#'     DO NOT REMOVE.
#' @import shiny
#' @importFrom shinythemes shinytheme
#' @noRd
app_ui <- function(request) {
  tagList(
    # Leave this function for adding external resources
    golem_add_external_resources(),
    # Your application UI logic 
    navbarPage(
             header = list(
        tags$script(HTML("var header = $('.navbar > .container-fluid');
header.append('<div style=\"float:right\"><ahref=\"URL\"><img src=\"https://raw.githubusercontent.com/munoztd0/xaringan/master/logo_plain.png\" alt=\"alt\" style=\"float:right;width:100px;height:41px;padding-top:10px;\"> </a></div>');
    console.log(header)")),
        tags$script(HTML("var header = $('.navbar > .container-fluid');
 header.append('<div style=\"float:right;height:30px;padding-right:50px;\"><h5></h5></div>');"))
      ),
      "laPizzeria",
      theme = shinytheme("paper"),
      id = "tabs",
       tabPanel("Play With the List",
          mod_interaction_with_list_ui("interaction_with_list_ui_1")
       ),
       tabPanel("Live Watchlist Metrics",
          mod_real_time_client_metrics_ui("real_time_client_metrics_ui_1")
       ),
      tabPanel("RealTime Exposure",
          mod_real_time_exposure_by_security_ui("real_time_exposure_by_security_ui_1")
      )
    )
  )
}

#' Add external Resources to the Application
#' 
#' This function is internally used to add external 
#' resources inside the Shiny application. 
#' 
#' @import shiny
#' @importFrom golem add_resource_path activate_js favicon bundle_resources
#' @noRd
golem_add_external_resources <- function(){
  
  add_resource_path(
    'www', app_sys('app/www')
  )
 
  tags$head(
     tags$link(rel = "shortcut icon", href = "https://raw.githubusercontent.com/munoztd0/xaringan/master/favicon.ico"), favicon(),
    bundle_resources(
      path = app_sys('app/www'),
      app_title = 'laPizzeria'
    )
    # Add here other external resources
    # for example, you can add shinyalert::useShinyalert() 
  )
}

