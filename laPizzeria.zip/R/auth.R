authorized_emails <- c(
  "pierre.saouter@flowbank.com",
  "florent.mazeas@flowbank.com",
  "charles.sabet@flowbank.com",
  "adrien.cohen@flowbank.com",
  "chs"
)

#' @noRd 
#' @keywords internal
sign_in <- function(ns){
  modalDialog(
    title = "Sign in",
    textInput(ns("signin_email"), "Your email", width = "100%"),
    passwordInput(ns("signin_password"), "Your password", width = "100%"),
    nter::nter(ns("sign_in"), ns("signin_password")),
    footer = actionButton(ns("sign_in"), "Sign in"),
    size = "s"
  )
}

#' Check emails used
#' 
#' @param email Email address to check
#' 
#' @noRd 
#' @keywords internal
check_email <- function(email){
  is_in_team <- (email %in% authorized_emails)

  if(is_in_team)
    return(TRUE)

  FALSE
}