#' Retrieve last price for a given symbol
#' 
#' Retrieve last price for a given symbol
#' 
#' @description
#' Based on the ticks database, retrieving the last price
#'  for a given symbol
#' 
#' @param Symbol_ Symbol
#' 
#' @examples
#' \dontrun{
#'  dt <- Get_Last_Price(Symbol)
#'}
#'
#' @return a tibble
#'
#' @importFrom dplyr tbl select distinct collect right_join mutate filter summarise_all arrange slice
#' @importFrom data.table data.table
#' @export
Get_Last_Price <- function(Symbol_){

        From <- Sys.time()+3600-3600*96
        To <- Sys.time()+3600
        From <- From %>% as.character
        To <- To %>% as.character

        con <- flowbankanalytics::connect_ticks()

        on.exit({
                DBI::dbDisconnect(con)
        })

        SymbolId_ <- tbl(con, "Symbols") %>%
                dplyr::filter(Symbol %in% Symbol_) %>%
                select(Symbol, ID) %>%
                collect 

        List_ids <- SymbolId_$ID

        tbl(con, "Ticks") %>%
                dplyr::filter(SymbolID %in% List_ids & TimeStamp >= From & TimeStamp <= To) %>%
                select(ID = "SymbolID", Bid, Ask, TimeStamp) %>%
                group_by(ID) %>%
                arrange(desc(TimeStamp)) %>%
                mutate(Row_num = row_number()) %>%
                ungroup() %>%
                filter(Row_num == 1) %>%
                mutate(MidBidAsk = (Bid+Ask)/2) %>%
                select(-Row_num) %>%
                collect %>%
                full_join(., SymbolId_, by = "ID") %>%
                group_by(Symbol) %>%
                slice(1) %>%
                ungroup()

}

#########################################################
####################### LCG #############################
#########################################################

#' Retrieve Real-Time Position
#' 
#' Retrieve LCG Client Positions for today's Day
#' 
#' @description
#' The dwh_master database contains all tables related to the LCG business, including most
#' information related to trading activities and a few tables related to marketing.
#' 
#' @param Ids_LCG TradingAccountNumber
#' @param with_price lastprice or not?
#' 
#' @examples
#' \dontrun{
#'  dt <- LCG_Current_Position()
#'}
#'
#' @return a tibble
#'
#' @importFrom dplyr tbl select distinct collect right_join mutate filter summarise_all full_join ungroup mutate_at
#' @importFrom data.table data.table
#'
#' @export
LCG_Current_Position <- function(Ids_LCG = NULL, with_price = FALSE){
########## Position D-1
#   marketid <- full_join(
#           tbl(con_lcg, "vwMarket") %>%
#                          filter(Platform != "HEDGE") %>%
#                           select(MarketId = "ID", generalMultiplier, Currency = "QuoteCurrency", ContractSize = "CFDContractSize", Platform, AssetSector) %>%
#                           distinct %>%
#                           mutate(ContractSize = ifelse(Platform == "LCGTRADER", ContractSize/100, ContractSize)),
#           tbl(con_lcg, "vwTrade") %>%
#                    filter(Platform != "HEDGE") %>%
#                   select(MarketId, Symbol, Platform) %>%
#                 distinct,
#          by = c("MarketId", "Platform")) %>%
#          collect %>%
#         mutate(Platform = ifelse(Platform == "LCGTRADER", "LCGTrader", Platform))

con_quant <- flowbankanalytics::connect_quant()
con_lcg <- flowbankanalytics::connect_lcg()

on.exit({
                DBI::dbDisconnect(con_lcg)
                DBI::dbDisconnect(con_quant)
        })

marketid <- tbl(con_quant, "mapping_marketid_symbol_lcg") %>%
        collect 

Position_lcg <- flowbankanalytics::lcg_client_position_daily(con_lcg,trading_ids=Ids_LCG, time_since = Sys.Date()-1) %>%
        mutate(Platform = ifelse(Platform == "LCGTRADER", "LCGTrader", Platform))

if(nrow(Position_lcg) > 0 ){
        Position_lcg <- Position_lcg %>%
        group_by(TradingAccountNumber, PositionID, Platform, AssetType, Symbol, BasemarketName, MarketId, BuySell, AvgPrice = VWAPPrice) %>%
        summarise(
                VolumeLots = sum(VolumeLots, na.rm = TRUE),
                .groups = "drop"
        ) %>%
       left_join(
                .,
                marketid %>% select(-ContractSize),
                by = c("Symbol","MarketId", "Platform")
        ) %>%
        mutate(AvgPrice = AvgPrice*generalMultiplier) %>%
        select(-MarketId, - generalMultiplier) %>%
        mutate(AssetType = ifelse(AssetSector == "Cryptos", AssetSector, AssetType)) %>%
        select(-AssetSector) 

        PositionID_ <- Position_lcg$PositionID

        } else {
        Position_lcg <- tibble::tibble()
        PositionID_ <- NULL
}

######### Trade D Day
DateTime <- as.character(paste(Sys.Date(),"00:00:00.000"))
Trades_lcg <- tbl(con_lcg, "vwTrade") %>%
                filter(TradeTime >= DateTime & IsDemo != "TRUE" & IsTest != "TRUE") %>%
                filter(!TradingAccountGroup %like% '%Coverage%' & !TradingAccountGroup %like% '%MAM%' & !TradingAccountGroup %like% '%MM%')

if(!is.null(Ids_LCG)){
        Trades_lcg <- Trades_lcg %>%
        filter(TradingAccountNumber %in% Ids_LCG)
}       
Trades_lcg <- Trades_lcg %>%
        mutate(AssetType = case_when(
                        FSACode == "A" ~ "Equities",
                        FSACode == "U" ~ "FOREX",
                        FSACode == "I" ~ "Indices",
                        FSACode == "M" ~ "Commodities",
                        FSACode == "O" ~ "OPTION",
                        FSACode == "B" ~ "Fixed Income",
                        FSACode == "C" ~ "Cryptos",
                        TRUE ~ "Others"
                )) %>%
                mutate(BuySell = case_when(
                        Platform == "MT4" & OpenClose == "Close" & BuySell == "Buy" ~ "Sell",
                        Platform == "MT4" & OpenClose == "Close" & BuySell == "Sell" ~ "Buy",
                        TRUE ~ BuySell
                )) %>%
                mutate(Sign = ifelse(BuySell == "Buy", 1,-1)) %>%
        mutate(AdjustedVolume = Sign*VolumeLots) %>%
        collect

if(nrow(Trades_lcg)>0){

        prices <- Trades_lcg %>%
        group_by(PositionID, BuySell, MarketId, Platform) %>%
        summarise(
                AvgPrice = weighted.mean(TradePrice, VolumeLots),
                .groups = "drop"
        ) %>%
        left_join(
                .,
                marketid %>% select(-ContractSize),
                by = c("MarketId", "Platform")
        ) %>%
        mutate(AvgPrice = AvgPrice*generalMultiplier) %>%
        select(PositionID, BuySell, AvgPrice, Currency, AssetSector, Platform)

Trades_lcg_with_price <- Trades_lcg %>%
        group_by(TradingAccountNumber, PositionID, AssetType, Symbol, BasemarketName) %>%
        summarise(
                AdjustedVolume= sum(AdjustedVolume, na.rm = TRUE),
                .groups = "drop"
        ) %>%
        filter(AdjustedVolume != 0) %>%
        mutate(AdjustedVolume = round(AdjustedVolume, digits = 7)) %>%
        mutate(BuySell = ifelse(AdjustedVolume > 0, "Buy", "Sell")) %>%
        left_join(.,prices, by=c("PositionID", "BuySell")) %>%
        mutate(AssetType = ifelse(AssetSector == "Cryptos", AssetSector, AssetType)) %>%
        select(-AssetSector)

} else {
        Trades_lcg_with_price <- tibble::tibble()
}       

########## Updated position taking into account trades of D Day

if(nrow(Position_lcg) > 0 & nrow(Trades_lcg_with_price) > 0) {

        Position_updated <- full_join(
                Position_lcg %>%
                        rename(AvgPrice_Yesterday = AvgPrice) %>%
                        rename(VolumeLots_Yesterday = VolumeLots),
                Trades_lcg_with_price,
                by = c("TradingAccountNumber", "PositionID", "AssetType", "Symbol", "BasemarketName", "BuySell", "Currency", "Platform")
        ) %>%
        mutate_at(., c("AdjustedVolume", "AvgPrice", "AvgPrice_Yesterday", "VolumeLots_Yesterday"), ~replace(., is.na(.), 0)) %>%
        mutate(CurrentVolume = VolumeLots_Yesterday+AdjustedVolume) %>%
        filter(CurrentVolume != 0) %>%
        mutate(CurrentAvgPrice = case_when(
                AdjustedVolume == 0 ~ AvgPrice_Yesterday,
                VolumeLots_Yesterday == 0 ~ AvgPrice,
                AdjustedVolume != 0 & VolumeLots_Yesterday != 0 ~ (AvgPrice_Yesterday*VolumeLots_Yesterday+AvgPrice*AdjustedVolume)/CurrentVolume
        )) %>%
        group_by(TradingAccountNumber, PositionID, AssetType, Symbol, BasemarketName, Currency, Platform) %>%
        mutate(CurrentVolumeLots = sum(CurrentVolume)) %>%
        ungroup() %>%
        filter(sign(CurrentVolumeLots) == sign(CurrentVolume)) %>%
        select(TradingAccountNumber, PositionID, Platform, AssetType, Symbol, BasemarketName, BuySell, Currency, CurrentAvgPrice, CurrentVolumeLots)

} else if(nrow(Position_lcg) == 0 & nrow(Trades_lcg_with_price) > 0) {
        Position_updated <- Trades_lcg_with_price %>%
                select(TradingAccountNumber, PositionID, AssetType, Symbol, Platform, BasemarketName, BuySell, Currency, CurrentAvgPrice = "AvgPrice", CurrentVolumeLots = "AdjustedVolume")

} else if(nrow(Position_lcg) > 0 & nrow(Trades_lcg_with_price) == 0){

        Position_updated <- Position_lcg %>%
                select(TradingAccountNumber, PositionID, AssetType, Symbol, Platform, BasemarketName, BuySell, Currency, CurrentAvgPrice = "AvgPrice", CurrentVolumeLots = "VolumeLots")

} else if(nrow(Position_lcg) == 0 & nrow(Trades_lcg_with_price) == 0){

        Position_updated <- tibble::tibble()

}

########## Adding current price
if(with_price == TRUE & nrow(Position_updated)>0){
        Symbols <- unique(Position_updated$Symbol)
        LastPrice <- Get_Last_Price(Symbols) %>%
                left_join(., marketid %>% select(-ContractSize), by = "Symbol") %>%
                mutate(MidBidAsk = MidBidAsk*generalMultiplier) %>%
                select(Symbol, LastPrice = "MidBidAsk", Currency) %>%
                distinct

        Position_updated <- left_join(Position_updated, LastPrice, by = c("Symbol", "Currency"))
}

        Position_updated <- left_join(
                Position_updated,
                marketid %>% select(Symbol, Platform, ContractSize),
                by = c("Symbol", "Platform")
        ) %>%
        mutate(CurrentVolumeLots = CurrentVolumeLots*ContractSize) %>%
        select(-ContractSize)

return(Position_updated)
}

#' Retrieve Real-Time Equity and Exposure
#' 
#' Retrieve LCG Client Equity and Exposure
#' 
#' @description
#' The dwh_master database contains all tables related to the LCG business, including most
#' information related to trading activities and a few tables related to marketing.
#' 
#' @param AccountNo TradingAccountNumber
#' 
#' @examples
#' \dontrun{
#'  dt <- Get_Equity_Exposure_LCG(Id)
#'}
#'
#' @return a datatable
#'
#' @importFrom dplyr tbl select distinct collect right_join mutate filter summarise_all rename left_join group_by
#' @importFrom data.table data.table
#'
#' @export
Get_Equity_Exposure_LCG <- function(AccountNo){

        con_lcg <- flowbankanalytics::connect_lcg()

        on.exit({
                DBI::dbDisconnect(con_lcg)
        })

        ########## Current Price and current volume/exposure
        Pos_client <- LCG_Current_Position(AccountNo, with_price = TRUE)

        rate <- flowbankanalytics::get_rate_lcg(con_lcg, from_curr= "GBP", to_curr = "CHF", time_since = Sys.Date(), time_to = Sys.Date()) %>%
                select(Rate) %>%
                as.numeric

        Balance <- tbl(con_lcg, "vwCurrentBalance") %>%
                filter(TradingAccountNumber %in% AccountNo) %>%
                select(TradingAccountNumber, BalanceGBP) %>%
                mutate(BalanceCHF = BalanceGBP*rate) %>%
                collect
        
        if(nrow(Pos_client) > 0) {
                Pos_client <- Pos_client %>%
                mutate(Exposure = LastPrice*CurrentVolumeLots) %>%
                mutate(OpenPnL = ifelse(BuySell == "Buy",abs(CurrentVolumeLots)*(LastPrice-CurrentAvgPrice),abs(CurrentVolumeLots)*(CurrentAvgPrice-LastPrice))) %>%
                mutate(Currency = ifelse(Currency == "GBp", "GBPence", Currency))

        rates <- flowbankanalytics::get_rate_lcg(con_lcg, from_curr= unique(Pos_client$Currency), to_curr = "CHF", time_since = Sys.Date(), time_to = Sys.Date()) %>%
                select(Currency, Rate) 
        
        Pos_client <- merge(Pos_client, rates, by="Currency", all = TRUE) %>%
                        mutate(Currency = ifelse(Currency == "GBPence", "GBp", Currency)) %>%
                        mutate(ExposureCHF = Exposure*Rate) %>%
                        mutate(OpenPnLCHF = OpenPnL*Rate)

        Exposure <- Pos_client %>%
                select(TradingAccountNumber, ExposureCHF) %>%
                dplyr::group_by(TradingAccountNumber) %>%
                summarise_all(sum, na.rm=TRUE) %>%
                rename(Exposure = ExposureCHF)

        OpenPnL <- Pos_client %>%
                select(TradingAccountNumber, OpenPnLCHF) %>%
                group_by(TradingAccountNumber) %>%
                summarise_all(sum, na.rm = TRUE)

        Equity <- merge(Balance, OpenPnL, by = "TradingAccountNumber", all = TRUE) %>%
                        replace(is.na(.),0) %>%
                        mutate(Equity = BalanceCHF + OpenPnLCHF) %>%
                        select(TradingAccountNumber, Equity) 
        } else {

                Equity <- Balance %>%
                        select(TradingAccountNumber, Equity = "BalanceCHF")

                Exposure <- tibble::tibble(TradingAccountNumber = Balance$TradingAccountNumber) %>%
                        mutate(Exposure = 0)
        }

        Eq_Exp <- merge(Exposure, Equity, by="TradingAccountNumber", all = TRUE) %>%
                        replace(is.na(.),0) %>%
                        mutate(ExpRatio = Exposure/Equity)

        return(Eq_Exp)
}

#########################################################
######################## FB #############################
#########################################################

#' Retrieve Real-Time Position
#' 
#' Retrieve FB Client Positions for today's Day
#' 
#' @description
#' The datahub database contains all tables related to the FB business, including most
#' information related to trading activities and a few tables related to marketing.
#' 
#' @param FB_ids PortfolioRef
#' 
#' @examples
#' \dontrun{
#'  dt <- Get_D_Day_Position(con_hub, ids)
#'}
#'
#' @return a datatable
#'
#' @importFrom dplyr tbl select distinct collect right_join mutate filter summarise_all
#' @importFrom data.table data.table
#'
#' @export
FB_Current_Position <- function(FB_ids = NULL){

 con_hub <- flowbankanalytics::connect_data_hub()

        on.exit({
        DBI::dbDisconnect(con_hub)
        })

Portfolio <- tbl(con_hub, "Portfolio") %>%
                filter(!PortfolioRef %in% list_portfolio_refs_excl) %>%
                select(PortfolioRef, PortfolioId)


if (!is.null(FB_ids)) {
        Portfolio <- Portfolio %>%
            filter(PortfolioRef %in% FB_ids)
    }

Portfolio <- Portfolio %>%
        collect


PortfolioId_ <- Portfolio$PortfolioId

tbl(con_hub, "Position") %>%
             filter(PortfolioId %in% PortfolioId_ & ( Quantity != 0 | Type == "CURRENCY")) %>%
             select(PortfolioId, Type, ConvertedValue, ConvertedPnl, AveragePrice, Currency, Quantity, ContractMultiplier, SymbolId, ShortName) %>%
             mutate(Quantity = Quantity * ContractMultiplier) %>%
             mutate(BuySell = ifelse(Quantity > 0, "Buy", "Sell")) %>%
             collect %>%
             left_join(., Portfolio, by="PortfolioId", all = TRUE) %>%
             flowbankanalytics::clean_fb_asset_classes() %>%
             mutate(ConvertedValue = ifelse(Type == "CURRENCY", ConvertedValue,abs(ConvertedValue))) %>%
             mutate(LastPrice = ConvertedValue/Quantity) %>%
             mutate(SubClass = ifelse(grepl(".CRYPTO.", SymbolId), "Cryptos", SubClass)) %>%
             select(PortfolioRef, AssetType = "SubClass", SymbolId, ShortName, BuySell, Currency, CurrentAvgPrice = AveragePrice, CurrentVolumeLots = "Quantity" , VolumeCHF = "ConvertedValue", LastPrice, ConvertedPnl)

}

#' Retrieve Real-Time Equity and Exposure
#' 
#' Retrieve FB Client Equity and Exposure
#' 
#' @description
#' The datahub contains all tables related to the FB business, including most
#' information related to trading activities and a few tables related to marketing.
#' 
#' @param FB_ids PortfolioRef
#' 
#' @examples
#' \dontrun{
#'  dt <- Get_Equity_Exposure_FB(con_hub, IDs)
#'}
#'
#' @return a tibble
#'
#' @importFrom dplyr tbl select distinct collect right_join mutate filter summarise_all rename left_join group_by summarise
#' @importFrom data.table data.table
#'
#' @export
Get_Equity_Exposure_FB <- function(FB_ids){

        con_hub <- flowbankanalytics::connect_data_hub()

        on.exit({
        DBI::dbDisconnect(con_hub)
        })

        Pos_client <- FB_Current_Position(FB_ids) %>%
                mutate(Type = ifelse(AssetType %in% c("BOND", "CURRENCY", "FUND", "FUTURE", "STOCK"), "CASH", "CFD"))

        Equity <- left_join(
                        Pos_client %>%
                                filter(Type != "CFD") %>%
                                group_by(PortfolioRef) %>%
                                summarise(
                                        ConvertedValue = sum(VolumeCHF, na.rm = TRUE),
                                        .groups = "drop",
                                ),
                        Pos_client %>%
                                filter(Type == "CFD") %>%
                                group_by(PortfolioRef) %>%
                                summarise(
                                        ConvertedPnl = sum(ConvertedPnl, na.rm = TRUE),
                                        .groups = "drop",
                                ),
                        by = "PortfolioRef"
                ) %>%
                replace(is.na(.), 0) %>%
                mutate(Equity = ConvertedValue + ConvertedPnl) %>%
                select(PortfolioRef, Equity)


        Exposure <- Pos_client %>%
                                filter(Type != "CURRENCY") %>%
                                mutate(Exposure = VolumeCHF) %>%
                                group_by(PortfolioRef) %>%
                                summarise(
                                        Exposure = abs(sum(Exposure, na.rm = TRUE)),
                                        .groups = "drop",
                                )             

        Eq_Exp <- merge(Exposure, Equity, by="PortfolioRef", all = TRUE) %>%
                        setnafill(fill=0, cols = c("Exposure", "Equity")) %>%
                        mutate(ExpRatio = Exposure/Equity)

        return(Eq_Exp)                
}

#' Retrieve LCG Account
#' 
#' Retrieve LCG Account
#' 
#' @description
#' The dwh_master contains all tables related to the LCG business, including most
#' information related to trading activities and a few tables related to marketing.
#' 
#' @param con connection to database
#' @param TradingID TradingAccountNumber
#' 
#' @examples
#' \dontrun{
#'  dt <- Get_LCG_Account(con_hub, IDs)
#'}
#'
#' @return a datatable
#'
#' @importFrom dplyr tbl select distinct collect  mutate filter 
#' @importFrom data.table data.table
#'
#' @export
Get_LCG_Account <- function(con, TradingID){
        
        ID <- tbl(con, "vwTradingAccount") %>%
                filter(TradingAccountNumber == TradingID) %>%
                select(Name = "ClientName", TradingAccountNumber) %>%
                distinct %>%
                mutate(Platform = "LCG") %>%
                collect %>%
                data.table

        return(ID)
}

#' Current Positions
#' 
#' Current Positions LCG+FB
#' 
#' @description
#' 
#' Current positions
#' 
#' @param FB_ids FB
#' @param AccountNo LCG
#' @param with_timestamp with or without timestamp
#' 
#' @examples
#' \dontrun{
#'  dt <- Global_Current_Position(FB_IDS, LCG_IDS)
#'}
#'
#' @return a tibble
#'
#' @importFrom dplyr tbl select distinct collect  mutate filter case_when group_by arrange bind_rows mutate_at
#' @importFrom data.table data.table
#' @import flowbankanalytics
#'
#' @export
Global_Current_Position <- function(FB_ids = NULL, AccountNo = NULL, with_timestamp = FALSE)
{
        con_hub <- flowbankanalytics::connect_data_hub()
        con_lcg <- flowbankanalytics::connect_lcg() 
        con_ticks <- flowbankanalytics::connect_ticks()
        con_quant <- flowbankanalytics::connect_quant()

        on.exit({
                DBI::dbDisconnect(con_lcg)
                DBI::dbDisconnect(con_hub)
                DBI::dbDisconnect(con_ticks)
                DBI::dbDisconnect(con_quant)
        })

        Pos_client_FB <- FB_Current_Position(FB_ids) %>%
                filter(AssetType != "CURRENCY") %>%
                left_join(tbl(con_quant, "trade_universal_basemarketnames") %>% rename(AssetType = SubClass) %>% collect, by = c("SymbolId", "AssetType")) %>%
                mutate(BasemarketName = ifelse(grepl("CRYPTO", SymbolId), gsub("/","",sub("\\.CRYPTO.*", "", SymbolId)), BasemarketName)) %>%
                group_by(PortfolioRef, Currency, AssetType, BasemarketName, BuySell) %>%
                summarise(
                        Quantity = sum(CurrentVolumeLots, na.rm = TRUE),
                        VolumeCHF = sum(VolumeCHF, na.rm = TRUE),
                        .groups = "drop"
                ) %>%
                select(Account = "PortfolioRef", AssetType, BasemarketName, BuySell, Currency, Quantity_FB = "Quantity", VolumeCHF_FB = "VolumeCHF") %>%
                mutate(Segment = "Flowbank")

        timestamp <- Sys.time()

        Pos_client_LCG <- LCG_Current_Position(AccountNo, with_price = TRUE) %>%
                mutate(Volume = LastPrice*CurrentVolumeLots) %>%
                group_by(TradingAccountNumber, Currency, AssetType, BasemarketName, BuySell) %>%
                summarise(
                        Quantity_LCG = sum(CurrentVolumeLots, na.rm = TRUE),
                        Volume_LCG = sum(Volume, na.rm = TRUE),
                        .groups = "drop",
                ) %>%
                rename(Account = TradingAccountNumber) %>%
                mutate(Segment = "LCG")

        lcg_rate <- flowbankanalytics::get_rate_lcg(con_lcg, unique(Pos_client_LCG$Currency), "CHF",Sys.Date(),Sys.Date()) %>%
                select(Currency, Rate)

        Pos_client_LCG_CHF <- left_join(Pos_client_LCG, lcg_rate, by = "Currency") %>%
                mutate(VolumeCHF_LCG = Volume_LCG*Rate) %>%
                select(-Rate, - Volume_LCG)
        
        Pos <- dplyr::bind_rows(Pos_client_FB, Pos_client_LCG_CHF) %>%
                 mutate_at(., c("Quantity_FB", "VolumeCHF_FB", "Quantity_LCG", "VolumeCHF_LCG"), ~replace(., is.na(.), 0)) %>%
                 mutate(TotalQuantity = Quantity_FB + Quantity_LCG) %>%
                 mutate(TotalVolume = VolumeCHF_FB + VolumeCHF_LCG) %>%
                 rename(Symbol = BasemarketName)

        if(with_timestamp == FALSE){
                to_return <- Pos
        } else {
                to_return <- list(timestamp,Pos)
        }

        return(to_return)
}


