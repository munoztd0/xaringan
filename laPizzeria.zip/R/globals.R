globalVariables(
  c(
    ".", "%>%", "Account", "AdjustedVolume", "Ask", "AveragePrice", "BalanceCHF", "BalanceGBP", "BasemarketName",
    "Bid", "BuySell", "ClientType", "ConvertedValue", "Currency", "CurrentVolume", "Equity", "Exposure", "ExposureCHF", "IB",
    "ID", "MidBidAsk", "Name", "OpenPnLCHF", "Platform", "PortfolioId", "PortfolioRef", "Quantity", "Rate", "PositionID",
    "RateCalculated", "RealizedPL", "ShortName", "Symbol", "SymbolID", "SymbolId", "TimeStamp", "TradeTime", "TradingAccountNumber", "Type", "VWAPPrice",
    "VolumeLots", "aggregate", "desc", "AdjustedContractSize", "AssetType", "Book", "BookType", "ContractMultiplier", "ConvertedPnl", "ExpRatio", "Quantity_FB",
    "Quantity_LCG", "Riskbook", "SubClass", "TotalQuantity", "Volume"))


list_portfolio_ids_excl <- c(19, 20, 21, 36)
list_portfolio_refs_excl <- c(
  "NZP0365.001", # historically excluded was a potential buyer for LCG (no trading revenue)
  "FZD0331.001", # historically excluded was a potential buyer for LCG (no trading revenue)
  "QGK0365.001", # historically excluded was a potential buyer for LCG (no trading revenue)
  "FLW1312.INTERNAL", # exclude on client side as we make money on hedge side
  "FLO1161.001", # compte de consignation
  "VFG0338.001", # LCG UK
  "VFG0338.002", # LCG UK
  "VFG0338.003", # LCG UK
  "VFG0338.004", # LCG UK
  "LTX0323.001", # bank/broker Cyprus
  "LTX0323.002", # bank/broker Cyprus
  "LTX0323.003", # bank/broker Cyprus
  "GJX0323.001", # LCG Capital Markets Limited entrée (hosue money)
  "GJX0323.002", # LCG Capital Markets Limited sortie (house account - client money)
  #"GJX0323.003", # LCG Capital Markets Limited trading physique
  "GJX0323.004", # LCG Capital Markets Limited rien dedands
  "BHS1295.001", # LCG
  # "ARC1274.001", # bank/broker
  # "ECH0304.001", # bank/broker
  # "DNC0324.001", # bank/broker
  # "DNC0324.002", # bank/broker
  # "QOD0335.001", # bank/broker
  # "PWX0335.001", # bank/broker
  # "ALC0339.001", # bank/broker
  # "FVX0339.001", # bank/broker
  # "LOB0325.001", # bank/broker
  # "ZGJ1054.001", # bank/broker
  # "SYV1139.001", # bank/broker
  # "XHV1148.001", # bank/broker
  # "QUA1176.001", # bank/broker
  # "TBK1182.001", # bank/broker
  # "JTB1191.001", # bank/broker
  # "IXK1202.001", # bank/broker
  # "LTX0323.001", # bank/broker
  # "LTX0323.002", # bank/broker
  # "LTX0323.003", # bank/broker
  "CDK0335.001", # Exante
  "ACC1012.001", # exclure
  "ACC1012.FLOWBANK", # exclure
  "ACC1012.CHARITYBOX", # exclure
  "CFD0185.BBOOK", # exclure
  "CFD0185.CASHBBOOK", # exclure
  "CFD0185.FXBBOOK", # exclure
  "MXS0329.001", # exclure
  "MXS0329.002", # exclure
  "CEY1229.001", # exclure
  "FEE1048.001", # Exante
  "FRC0213.FRACTIONNALSHARES", # exclure
  "OIF0338.001", # exclure compte test
  "OIF0338.002", # exclure compte test
  "OIF0338.003", # exclure compte test
  "OIF0338.004", # exclure compte test
  "OIF0338.005", # exclure compte test
  "OIF0338.006", # exclure compte test
  "OIF0338.007", # exclure compte test
  "OIF0338.008", # exclure compte test
  "UWQ1046.001" # exclure compte test
)
