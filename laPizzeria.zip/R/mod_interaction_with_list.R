#' interaction_with_list UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd 
#'
#' @importFrom shiny NS tagList 
mod_interaction_with_list_ui <- function(id){
  ns <- NS(id)
  tagList(
    div(
      fluidPage(
        fluidRow(
        actionButton(ns("Showlist"), "Show list"),
        actionButton(ns("Hidelist"), "Hide list"),
        DTOutput(ns("tbl_display_watchlist"))
        ),
        fluidRow(
          column(6,
          h3("Add a new client"),
          tabPanel("Search",
                        column(4,
                         textInput(ns("search_client"), label = "Type an account number to add in the list")),
                        column(2, 
                         actionButton(ns("OK"), icon("check")),
                         nter::nter(ns("OK"), ns("search_client"))),
                         #helpText("Type a client account number and search.")
                         ),
        DTOutput(ns("tbl_search_client")),
        h3(textOutput(ns("tbl_add_client")))
        ),
        column(6,
          h3("Remove a client"),
          uiOutput(ns("remove_client")),
          h3(textOutput(ns("tbl_remove_client")))
        )
      )      
    )
  )
)
}
    
#' interaction_with_list Server Functions
#'
#' @noRd 
mod_interaction_with_list_server <- function(id){
  moduleServer( id, function(input, output, session){
    ns <- session$ns
 
     # login modal
    # showModal(sign_in(ns))
    # 
    # observeEvent(input$sign_in, {
    #   if(
    #     (check_email(tolower(input$signin_email)) & input$signin_password == Sys.getenv("password_tradeInspect")) |
    #     (check_email(tolower(input$signin_email)) & input$signin_password == Sys.getenv("charles_pass")))
    #     removeModal()
    #     })

  con_quant <- golem::get_golem_options("con_quant")
  con_hub <- golem::get_golem_options("con_hub")
  con_lcg <- golem::get_golem_options("con_lcg")

  client_search <- reactive({
          req(input$OK)
          return(isolate(input$search_client))
        })

  watchlist <- tbl(con_quant, "trade_watchlist") %>%
               collect %>%
               select(TradingAccountNumber, Name, IB, Platform) %>%
               data.table 

  Reactive_List <- reactive({
    watchlist <- tbl(con_quant, "trade_watchlist") %>%
               collect %>%
               select(TradingAccountNumber, Name, IB, Platform) %>%
               data.table 
  })

  output$remove_client <- renderUI({
      selectInput(inputId = ns("remove_client"), label="Select a client to remove:",
      choices = list(`FlowBank` = paste(c(" ",Reactive_List()[Platform == "FlowBank"]$TradingAccountNumber), "-", c(" ",Reactive_List()[Platform == "FlowBank"]$Name)),
                      `LCG` = paste(Reactive_List()[Platform == "LCG"]$TradingAccountNumber, "-", Reactive_List()[Platform == "LCG"]$Name)), selected = NULL)
     })


  rv <- reactiveValues(x = watchlist)
  observeEvent(input$Showlist, {
    rv$x <- NULL
    rv$x <- tbl(con_quant, "trade_watchlist") %>%
               collect %>%
               select(TradingAccountNumber, Name, IB, Platform) %>%
               data.table
  })
  observeEvent(input$Hidelist, {
    rv$x <- NULL
  })

list_client_fb <- flowbankanalytics::get_person_account(con_hub)

output$tbl_search_client <- renderDT({
    client <- client_search()

    dat <- list_client_fb %>%
            filter(Account == client) %>%
            select(Account, Name, ClientType, PortfolioRef) %>%
            rename(TradingAccountNumber = PortfolioRef) %>%
            mutate(Platform = "FlowBank")  
    
    if(nrow(dat) == 0){
      dat <- Get_LCG_Account(con_lcg, client)
    }

    dat %>%
    datatable(
        style = 'bootstrap4',
        selection = "single",
        escape = FALSE,
        rownames = FALSE,
        caption = "Result of the client search - click on a line to add in watchlist",
        options = list(
          dom = 'Bfrtip',
          pageLength = 10,
        columnDefs = list(list(className = 'dt-center',targets = c(0:(ncol(dat)-1))))
      ))
})

output$tbl_add_client <- renderText({

    client <- client_search()
    dat <- list_client_fb %>%
            filter(Account == client) %>%
            select(Account, Name, ClientType, PortfolioRef) %>%
            rename(TradingAccountNumber = PortfolioRef) %>%
            mutate(Platform = "FlowBank") 

    if(nrow(dat) == 0){
      dat <- Get_LCG_Account(con_lcg, client)
    }

     line_selected <- input$tbl_search_client_rows_selected
     PortfolioRef_selected <- dat[line_selected,]$TradingAccountNumber

    if(length(PortfolioRef_selected) > 0) {
     text <- paste("Adding", PortfolioRef_selected, "in the watchlist")

    list <- Watchlist()
    
    list <- dplyr::bind_rows(list,
    dat %>%
        select(TradingAccountNumber, Name, Platform) %>%
        filter(TradingAccountNumber == PortfolioRef_selected) 
    )
    
    DBI::dbWriteTable(con_quant, "trade_watchlist", list, overwrite=TRUE)

    } else {
      text <- ""
    }

  text <- text
})

output$tbl_remove_client <- renderText({

    string <- input$remove_client
    AccountNumber <- stringr::str_split(string, "-")[[1]][1] %>% trimws()
    
    if(AccountNumber != "")
    {
    list <- Watchlist() %>%
          filter(TradingAccountNumber != AccountNumber)    

    DBI::dbWriteTable(con_quant, "trade_watchlist", list, overwrite=TRUE)
    Reactive_List()
    text <- paste("Removing", AccountNumber, "from watchlist")
    } else {
      text <- ""
    }
    text <- text
})


Watchlist <- reactive({
      watchlist <- tbl(con_quant, "trade_watchlist") %>%
                  collect %>%
                  select(TradingAccountNumber, Name, IB, Platform) %>%
                  data.table 
      return(watchlist)
})

 output$tbl_display_watchlist <- renderDT({
     dat <- rv$x  
     if(length(dat) > 0 ){
     dat %>%
      datatable(
        style = 'bootstrap4',
        selection = "single",
        escape = FALSE,
        rownames = FALSE,
        caption = "Watchlist: special clients",
        options = list(
          dom = 'Bfrtip',
          pageLength = 10,
        columnDefs = list(list(className = 'dt-center',targets = c(0:(ncol(dat)-1))))
      ))}
})

})
}
    
## To be copied in the UI
# mod_interaction_with_list_ui("interaction_with_list_ui_1")
    
## To be copied in the server
# mod_interaction_with_list_server("interaction_with_list_ui_1")
