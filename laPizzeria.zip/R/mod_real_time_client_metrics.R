#' real_time_client_metrics UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd 
#'
#' @importFrom shiny NS tagList 
#' @importFrom DT DTOutput
#' @importFrom shinydashboard valueBoxOutput box
#' @import waiter

mod_real_time_client_metrics_ui <- function(id){
  ns <- NS(id)
  tagList(

    tags$style(
      ".colorok {color:#3AB147}",
      ".colornok {color:#C21A1A}"
      ),

     tags$style(HTML("
.col-sm-12 {
    /* background-color: #3CBA7E; */
    border: solid;
    border-left-width: 4 px;
    border-right-width: 4 px
    border-bottom-width: 4 px;
    border-top-width: 4 px;
    border-color: #3CBA7E;
    padding: 10 px 20 px;
    width: fit-content;
}")),

  div(
    fluidPage(
      use_waiter(),
      shinyjs::useShinyjs(),
      
       fluidRow(
                column(6, 
                shinydashboard::box(status = "primary", width = 12, title = tags$b("Realtime exposure"), solidHeader = TRUE, footer = "Calculation based on TicksDB",
                     column(6, offset = 0,
                            valueBoxOutput(ns("total_exposure_lcg"), width = 3)),
                     column(6, offset = 0,
                            valueBoxOutput(ns("total_exposure_fb"), width = 3)))),


                column(6,      
                shinydashboard::box(status = "primary", width = 12, title = tags$b("Realtime equity"), solidHeader = TRUE, footer = "Calculation based on TicksDB",
                     column(6, offset = 0,
                            valueBoxOutput(ns("total_equity_lcg"), width = 3)),
                     column(6, offset = 0,
                            valueBoxOutput(ns("total_equity_fb"), width = 3)
       )))),
    
      fluidRow(
        column(9, align="center",
      actionButton(ns("refresh"), "Calculate")),
      ),

       fluidRow(
        DTOutput(ns("tbl_display_top5")),
        DTOutput(ns("tbl_realtime_positions"))
       )
    )
  )
  )
}
    
#' real_time_client_metrics Server Functions
#'
#' @noRd 
#' @import data.table
#' @importFrom DT DTOutput datatable renderDT formatStyle formatRound styleEqual
#' @importFrom shinydashboard renderValueBox valueBox
mod_real_time_client_metrics_server <- function(id){
  moduleServer( id, function(input, output, session){
    ns <- session$ns

  con_lcg <- golem::get_golem_options("con_lcg")
  con_hub <- golem::get_golem_options("con_hub")
  con_quant <- golem::get_golem_options("con_quant")


  #################
  watchlist <- tbl(con_quant, "trade_watchlist") %>%
    collect %>%
    select(TradingAccountNumber, Name, IB, Platform)

  FB_ids <- watchlist %>%
    filter(Platform == "FlowBank") %>%
    dplyr::pull(TradingAccountNumber)

  LCG_ids <- watchlist %>%
    filter(Platform == "LCG") %>%
    dplyr::pull(TradingAccountNumber)
 
Refresh <- eventReactive(input$refresh, {
  waiter_show(
     color = "#2c2e39",
     html = tagList(
     spin_wave(),
     "[Loading] Retrieving current prices in TicksDB & calculating exposure..."
    ))
   equity_exposure_all_fb <- Get_Equity_Exposure_FB(FB_ids)
   equity_exposure_all_lcg <- Get_Equity_Exposure_LCG(LCG_ids)
   waiter_hide()
   list(equity_exposure_all_fb,equity_exposure_all_lcg, Sys.time()+3600)
})


#################
output$update_time <- renderText({
    print(Refresh()[[3]])
    Refresh()[[3]]
  })

output$tbl_display_top5 <- renderDT({
    dat <- dplyr::bind_rows(
      Refresh()[[2]],
      Refresh()[[1]] %>% rename(TradingAccountNumber = PortfolioRef)
)

    dat <- merge(dat, watchlist %>% select(TradingAccountNumber, Name), by="TradingAccountNumber", all = TRUE) %>%
                    setnafill(fill=0, cols=c("Equity", "Exposure", "ExpRatio")) %>%
                    arrange(desc(ExpRatio)) %>%
                    select(Name, TradingAccountNumber, Exposure, Equity, ExpRatio) %>%
                    mutate(ExpRatio = ifelse(
                      ExpRatio <= 3,
                      paste(round(ExpRatio,2), as.character(icon("ok-sign", class ="colorok", lib="glyphicon")), sep= "&emsp;"),
                      paste(round(ExpRatio,2), as.character(icon("exclamation-sign", class = "colornok", lib = "glyphicon")), sep= "&emsp;")))

    dat %>%
    datatable(
        style = 'bootstrap4',
        selection = "single",
        escape = FALSE,
        rownames = FALSE,
        caption = "Equity and exposure by client in the watchlist",
        options = list(
          dom = 'Bfrtip',
          pageLength = 10,
        columnDefs = list(list(className = 'dt-center',targets = c(0:(ncol(dat)-1))))
      )) %>%
      formatRound(columns = as.numeric(which(sapply(dat, is.numeric))), mark = "'", digits = 2) 
})

output$total_exposure_lcg <- renderValueBox({
  print(sum(Refresh()[[2]]$Exposure) %>% as.numeric)
  expo_lcg <- sum(Refresh()[[2]]$Exposure) %>% as.numeric
  valueBox(subtitle = tags$h6(tags$b("LCG exposure")), value = format(round(expo_lcg,digits=2),nsmall=1, big.mark="'"))
})

output$total_exposure_fb <- renderValueBox({
    expo_fb <- sum(Refresh()[[1]]$Exposure) %>% as.numeric
    valueBox(subtitle = tags$h6(tags$b("Flowbank exposure")), value = format(round(expo_fb, digits=2),nsmall=1, big.mark="'"),
)})

output$total_equity_lcg <- renderValueBox({
    equity_lcg <- sum(Refresh()[[2]]$Equity) %>% as.numeric
    valueBox(subtitle = tags$h6(tags$b("LCG equity")), value = format(round(equity_lcg,digits=2),nsmall=1, big.mark="'"))
})

output$total_equity_fb <- renderValueBox({
    equity_fb <- sum(Refresh()[[1]]$Equity) %>% as.numeric
    
    valueBox(subtitle = tags$h6(tags$b("Flowbank equity")), value = format(round(equity_fb, digits=2),nsmall=1, big.mark="'"),
)})

output$tbl_realtime_positions <- renderDT({
    if(length(input$tbl_display_top5_rows_selected) > 0){
    dat <- dplyr::bind_rows(
      Refresh()[[2]],
      Refresh()[[1]] %>% rename(TradingAccountNumber = PortfolioRef)
    )
    dat <- merge(dat, watchlist %>% select(TradingAccountNumber, Name), by="TradingAccountNumber", all = TRUE) %>%
                    setnafill(fill=0, cols=c("Equity", "Exposure", "ExpRatio")) %>%
                    arrange(desc(ExpRatio)) %>%
                    select(Name, TradingAccountNumber, Exposure, Equity, ExpRatio) %>%
                    mutate(ExpRatio = ifelse(
                      ExpRatio <= 3,
                      paste(round(ExpRatio,2), as.character(icon("ok-sign", class ="colorok", lib="glyphicon")), sep= "&emsp;"),
                      paste(round(ExpRatio,2), as.character(icon("exclamation-sign", class = "colornok", lib = "glyphicon")), sep= "&emsp;")))

    line_selected <- input$tbl_display_top5_rows_selected
    PortfolioRef_selected <- dat[line_selected,]$TradingAccountNumber
    IsLCGorFB <- watchlist %>% filter(TradingAccountNumber == PortfolioRef_selected) %>% dplyr::pull(Platform)      

    if(IsLCGorFB == "FlowBank"){
      dat <- FB_Current_Position(PortfolioRef_selected) %>%
            filter(AssetType != "CURRENCY") %>%
            select(PortfolioRef, AssetType, CurrentAvgPrice, Currency, CurrentVolumeLots, ShortName) %>%
            group_by(PortfolioRef,AssetType,ShortName, Currency) %>%
            summarise(
              AveragePrice = mean(CurrentAvgPrice),
              Quantity = sum(CurrentVolumeLots, na.rm = TRUE),
              .groups = "drop",
            )
      
      }
    if(IsLCGorFB == "LCG"){
      dat <- LCG_Current_Position(Ids_LCG = PortfolioRef_selected) %>%
            select(TradingAccountNumber, Currency, BuySell, CurrentAvgPrice,CurrentVolumeLots, Symbol) %>%
            group_by(TradingAccountNumber, Currency, BuySell, Symbol) %>%
            summarise(
              AveragePrice = mean(CurrentAvgPrice),
              CurrentQuantity = sum(CurrentVolumeLots, na.rm = TRUE),
              .groups = "drop",
            )
      }
      
    dat %>%
      datatable(
        style = 'bootstrap4',
        #extensions = 'Buttons',
        selection = "single",
        escape = FALSE,
        rownames = FALSE,
        caption = "Positions",
        filter = 'bottom',
        options = list(
          #dom = "ftip",
          dom = 'Bfrtip',
          pageLength = 10,
        
        columnDefs = list(list(className = 'dt-center',targets = c(0:(ncol(dat)-1))))
      )) %>%
     formatStyle(columns = colnames(.$x$data), `font-size` = '12px') %>%
     formatRound(columns = as.numeric(which(sapply(dat, is.numeric))), mark = "'", digits = 2) 
    } else {

      dat <- data.table(Message="Please, select a line.")
      dat %>%
      datatable(
        style = 'bootstrap4',
        #extensions = 'Buttons',
        selection = "single",
        escape = FALSE,
        rownames = FALSE,
        caption = "Positions",
        filter = 'bottom',
        options = list(
          #dom = "ftip",
          dom = 'Bfrtip',
          pageLength = 20,
          # buttons = list("copy", list(
          #             extend = "collection"
          #             , buttons = c("csv", "excel", "pdf")
          #             , text = "Download"
          #           )),
        columnDefs = list(list(className = 'dt-center',targets = c(0:(ncol(dat)-1))))
      ))
    }

})

 



  })
}
    
## To be copied in the UI
# mod_real_time_client_metrics_ui("real_time_client_metrics_ui_1")
    
## To be copied in the server
# mod_real_time_client_metrics_server("real_time_client_metrics_ui_1")
