#' real_time_exposure_by_security UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd 
#'
#' @importFrom shiny NS tagList 
mod_real_time_exposure_by_security_ui <- function(id){
  ns <- NS(id)
  tagList(
    fluidPage(

      fluidRow(
        column(6, uiOutput(ns("sel_client"))),
        column(6, align="center",
      actionButton(ns("refresh"), "Calculate")),
      ),

      fluidRow(
        column(6, 
          h2("Equities"),
          DTOutput(ns("expo_equities")),
          h5("Equities: list of clients"),
          DTOutput(ns("clients_equities"))
          ), 

        column(6,
          h2("Commodities"),
          DTOutput(ns("expo_commodities")),
          h5("Commodities: list of clients"),
          DTOutput(ns("clients_commodities"))
      )),

      fluidRow(
        column(6, 
          h2("Forex"),
          DTOutput(ns("expo_forex")),
          h5("Forex: list of clients"),
          DTOutput(ns("clients_forex"))
          ), 

        column(6,
          h2("Indices"),
          DTOutput(ns("expo_indices")),
          h5("Indices: list of clients"),
          DTOutput(ns("clients_indices")))
      )

    )
 
  )
}
    
#' real_time_exposure_by_security Server Functions
#'
#' @noRd 
mod_real_time_exposure_by_security_server <- function(id){
  moduleServer( id, function(input, output, session){
    ns <- session$ns

  waiter_show(
      color = "#2c2e39",
      html = tagList(
      spin_wave(),
      "Loading data..."
    ))

  con_lcg <- golem::get_golem_options("con_lcg")
  con_hub <- golem::get_golem_options("con_hub")
  con_quant <- golem::get_golem_options("con_quant")

  list_of_clients <- dplyr::bind_rows(
    tibble::tibble(AccountNumber = "All"),
    dplyr::full_join(
    tbl(con_quant, "trade_fb_trade_summary_new") %>%
    select(AccountNumber = "PortfolioRef") %>%
    distinct,
    tbl(con_quant, "trade_lcg_trading_summary") %>%
    select(AccountNumber = "TradingAccountNumber") %>%
    distinct,
    by = "AccountNumber") %>%
    collect,
  )

  output$sel_client <- renderUI({
    selectizeInput(inputId = ns("Client_chosen"),
    label = "Select a Client account", 
    choices = list_of_clients$AccountNumber, 
    selected = "All", 
    multiple = TRUE)
})

  Refresh <- eventReactive(input$refresh, {
  waiter_show(
     color = "#2c2e39",
     html = tagList(
     spin_wave(),
     "[Loading] Retrieving current prices in TicksDB & calculating exposure..."
    ))


  Current_Pos <- Global_Current_Position() %>%
      rename(BasemarketName = Symbol)

  Account_chosen <- input$Client_chosen

  if(!("All" %in% input$Client_chosen)) {
      Current_Pos <- Current_Pos %>%
        filter(Account %in% Account_chosen)
    }

    Current_Pos_agg <- Current_Pos %>%
      group_by(AssetType, BasemarketName) %>%
      summarise(
        Quantity = sum(TotalQuantity, na.rm = TRUE),
        Volume = sum(TotalVolume, na.rm = TRUE),
        NoClients = dplyr::n_distinct(Account),
        .groups = "drop",
      )
      
      waiter_hide()

      return(list(Current_Pos,Current_Pos_agg))
  
})

  waiter_hide()
  
  output$expo_equities <- renderDT({

    dat <- Refresh()[[2]] %>%
      filter(AssetType == "Equities") %>%
      arrange(desc(Quantity))

    dat %>%
      datatable(
        style = 'bootstrap4',
        #extensions = 'Buttons',
        selection = "single",
        escape = FALSE,
        rownames = FALSE,
        caption = "Live exposure for equities",
        filter = 'bottom',
        options = list(
          #dom = "ftip",
          dom = 'Bfrtip',
          pageLength = 5,
        
        columnDefs = list(list(className = 'dt-center',targets = c(0:(ncol(dat)-1))))
      )) %>%
     formatStyle(columns = colnames(.$x$data), `font-size` = '12px') %>%
     formatRound(columns = as.numeric(which(sapply(dat, is.numeric))), mark = "'", digits = 2) 

  })

  output$clients_equities <- renderDT({

  if(length(input$expo_equities_rows_selected) > 0){

  line_selected <- input$expo_equities_rows_selected

  dat <- Refresh()[[2]] %>%
      filter(AssetType == "Equities") %>%
      arrange(desc(Quantity))

  asset_selected <- dat[line_selected,]$BasemarketName

  dat <- Refresh()[[1]] %>%
      filter(BasemarketName == asset_selected & AssetType == "Equities") %>%
      select(AssetType, BasemarketName, Account, Quantity = "TotalQuantity")

  dat %>%
      datatable(
        style = 'bootstrap4',
        #extensions = 'Buttons',
        selection = "single",
        escape = FALSE,
        rownames = FALSE,
        caption = "List of clients who have positions on equities",
        filter = 'bottom',
        options = list(
          #dom = "ftip",
          dom = 'Bfrtip',
          pageLength = 5,
        
        columnDefs = list(list(className = 'dt-center',targets = c(0:(ncol(dat)-1))))
      )) %>%
     formatStyle(columns = colnames(.$x$data), `font-size` = '12px') %>%
     formatRound(columns = as.numeric(which(sapply(dat, is.numeric))), mark = "'", digits = 2) 
    
  } else {
    dat <- data.table(Message = "Click on a line above to see the list of clients associated to a security")

    dat %>%
      datatable(
        style = 'bootstrap4',
        #extensions = 'Buttons',
        selection = "single",
        escape = FALSE,
        rownames = FALSE,
        caption = "List of clients who have positions on equities",
        filter = 'bottom',
        options = list(
          #dom = "ftip",
          dom = 'Bfrtip',
          pageLength = 5,
        
        columnDefs = list(list(className = 'dt-center',targets = c(0:(ncol(dat)-1))))
      ))
  }
  
  })

  output$expo_commodities <- renderDT({

    dat <- Refresh()[[2]] %>%
      filter(AssetType == "Commodities") %>%
      arrange(desc(Quantity))

    dat %>%
      datatable(
        style = 'bootstrap4',
        #extensions = 'Buttons',
        selection = "single",
        escape = FALSE,
        rownames = FALSE,
        caption = "Live exposure for commodities",
        filter = 'bottom',
        options = list(
          #dom = "ftip",
          dom = 'Bfrtip',
          pageLength = 5,
        
        columnDefs = list(list(className = 'dt-center',targets = c(0:(ncol(dat)-1))))
      )) %>%
     formatStyle(columns = colnames(.$x$data), `font-size` = '12px') %>%
     formatRound(columns = as.numeric(which(sapply(dat, is.numeric))), mark = "'", digits = 2) 

  })

  output$clients_commodities <- renderDT({

  if(length(input$expo_commodities_rows_selected) > 0){

  line_selected <- input$expo_commodities_rows_selected

  dat <- Refresh()[[2]] %>%
      filter(AssetType == "Commodities") %>%
      arrange(desc(Quantity))

  asset_selected <- dat[line_selected,]$BasemarketName

  dat <- Refresh()[[1]] %>%
      filter(BasemarketName == asset_selected & AssetType == "Commodities") %>%
      select(AssetType, BasemarketName, Account, Quantity = "TotalQuantity")

  dat %>%
      datatable(
        style = 'bootstrap4',
        #extensions = 'Buttons',
        selection = "single",
        escape = FALSE,
        rownames = FALSE,
        caption = "List of clients who have positions on commodities",
        filter = 'bottom',
        options = list(
          #dom = "ftip",
          dom = 'Bfrtip',
          pageLength = 5,
        
        columnDefs = list(list(className = 'dt-center',targets = c(0:(ncol(dat)-1))))
      )) %>%
     formatStyle(columns = colnames(.$x$data), `font-size` = '12px') %>%
     formatRound(columns = as.numeric(which(sapply(dat, is.numeric))), mark = "'", digits = 2) 
    
  } else {
    dat <- data.table(Message = "Click on a line above to see the list of clients associated to a security")

    dat %>%
      datatable(
        style = 'bootstrap4',
        #extensions = 'Buttons',
        selection = "single",
        escape = FALSE,
        rownames = FALSE,
        caption = "List of clients who have positions on commodities",
        filter = 'bottom',
        options = list(
          #dom = "ftip",
          dom = 'Bfrtip',
          pageLength = 5,
        
        columnDefs = list(list(className = 'dt-center',targets = c(0:(ncol(dat)-1))))
      ))
  }
  
  })

  output$expo_forex <- renderDT({

    dat <- Refresh()[[2]] %>%
      filter(AssetType == "FOREX") %>%
      arrange(desc(Quantity))

    dat %>%
      datatable(
        style = 'bootstrap4',
        #extensions = 'Buttons',
        selection = "single",
        escape = FALSE,
        rownames = FALSE,
        caption = "Live exposure for Forex",
        filter = 'bottom',
        options = list(
          #dom = "ftip",
          dom = 'Bfrtip',
          pageLength = 5,
        
        columnDefs = list(list(className = 'dt-center',targets = c(0:(ncol(dat)-1))))
      )) %>%
     formatStyle(columns = colnames(.$x$data), `font-size` = '12px') %>%
     formatRound(columns = as.numeric(which(sapply(dat, is.numeric))), mark = "'", digits = 2) 

  })

  output$clients_forex <- renderDT({

  if(length(input$expo_forex_rows_selected) > 0){

  line_selected <- input$expo_forex_rows_selected

  dat <- Refresh()[[2]] %>%
      filter(AssetType == "FOREX") %>%
      arrange(desc(Quantity))

  asset_selected <- dat[line_selected,]$BasemarketName

  dat <- Refresh()[[1]] %>%
      filter(BasemarketName == asset_selected & AssetType == "FOREX") %>%
      select(AssetType, BasemarketName, Account, Quantity = "TotalQuantity")

  dat %>%
      datatable(
        style = 'bootstrap4',
        #extensions = 'Buttons',
        selection = "single",
        escape = FALSE,
        rownames = FALSE,
        caption = "List of clients who have positions on forex",
        filter = 'bottom',
        options = list(
          #dom = "ftip",
          dom = 'Bfrtip',
          pageLength = 5,
        
        columnDefs = list(list(className = 'dt-center',targets = c(0:(ncol(dat)-1))))
      )) %>%
     formatStyle(columns = colnames(.$x$data), `font-size` = '12px') %>%
     formatRound(columns = as.numeric(which(sapply(dat, is.numeric))), mark = "'", digits = 2) 
    
  } else {
    dat <- data.table(Message = "Click on a line above to see the list of clients associated to a security")

    dat %>%
      datatable(
        style = 'bootstrap4',
        #extensions = 'Buttons',
        selection = "single",
        escape = FALSE,
        rownames = FALSE,
        caption = "List of clients who have positions on forex",
        filter = 'bottom',
        options = list(
          #dom = "ftip",
          dom = 'Bfrtip',
          pageLength = 5,
        
        columnDefs = list(list(className = 'dt-center',targets = c(0:(ncol(dat)-1))))
      ))
  }
  
  })



  output$expo_indices <- renderDT({

    dat <- Refresh()[[2]] %>%
      filter(AssetType == "Indices") %>%
      arrange(desc(Quantity))

    dat %>%
      datatable(
        style = 'bootstrap4',
        #extensions = 'Buttons',
        selection = "single",
        escape = FALSE,
        rownames = FALSE,
        caption = "Live exposure for indices",
        filter = 'bottom',
        options = list(
          #dom = "ftip",
          dom = 'Bfrtip',
          pageLength = 5,
        
        columnDefs = list(list(className = 'dt-center',targets = c(0:(ncol(dat)-1))))
      )) %>%
     formatStyle(columns = colnames(.$x$data), `font-size` = '12px') %>%
     formatRound(columns = as.numeric(which(sapply(dat, is.numeric))), mark = "'", digits = 2) 

  })

 output$clients_indices <- renderDT({

  if(length(input$expo_indices_rows_selected) > 0){

  line_selected <- input$expo_indices_rows_selected

  dat <- Refresh()[[2]] %>%
      filter(AssetType == "Indices") %>%
      arrange(desc(Quantity))

  asset_selected <- dat[line_selected,]$BasemarketName

  dat <- Refresh()[[1]] %>%
      filter(BasemarketName == asset_selected & AssetType == "Indices") %>%
      select(AssetType, BasemarketName, Account, Quantity = "TotalQuantity")

  dat %>%
      datatable(
        style = 'bootstrap4',
        #extensions = 'Buttons',
        selection = "single",
        escape = FALSE,
        rownames = FALSE,
        caption = "List of clients who have positions on indices",
        filter = 'bottom',
        options = list(
          #dom = "ftip",
          dom = 'Bfrtip',
          pageLength = 5,
        
        columnDefs = list(list(className = 'dt-center',targets = c(0:(ncol(dat)-1))))
      )) %>%
     formatStyle(columns = colnames(.$x$data), `font-size` = '12px') %>%
     formatRound(columns = as.numeric(which(sapply(dat, is.numeric))), mark = "'", digits = 2) 
    
  } else {
    dat <- data.table(Message = "Click on a line above to see the list of clients associated to a security")

    dat %>%
      datatable(
        style = 'bootstrap4',
        #extensions = 'Buttons',
        selection = "single",
        escape = FALSE,
        rownames = FALSE,
        caption = "List of clients who have positions on indices",
        filter = 'bottom',
        options = list(
          #dom = "ftip",
          dom = 'Bfrtip',
          pageLength = 5,
        
        columnDefs = list(list(className = 'dt-center',targets = c(0:(ncol(dat)-1))))
      ))
  }
  
  })

  })
}

## To be copied in the UI
# mod_real_time_exposure_by_security_ui("real_time_exposure_by_security_ui_1")
    
## To be copied in the server
# mod_real_time_exposure_by_security_server("real_time_exposure_by_security_ui_1")
