#' Run the Shiny Application
#'
#' @param user user to data hub DB (default is env data_hub_uid)
#' @param password password to data hub DB (default is env data_hub_pwd)
#' @param ... arguments to pass to golem_opts. 
#' See `?golem::get_golem_options` for more details.
#' @inheritParams shiny::shinyApp
#'
#' @export
#' @importFrom shiny shinyApp
#' @importFrom golem with_golem_options 
#' @importFrom DBI dbConnect dbDisconnect
run_app <- function(
  user = Sys.getenv("data_hub_uid"), 
  password = Sys.getenv("data_hub_pwd"),
  onStart = NULL,
  options = list(), 
  enableBookmarking = NULL,
  uiPattern = "/",
  ...
) {

  con_hub <- flowbankanalytics::connect_data_hub()
  con_lcg <- flowbankanalytics::connect_lcg()
  con_quant <- flowbankanalytics::connect_quant()

  with_golem_options(
    app = shinyApp(
      ui = app_ui,
      server = app_server,
      onStart = function(){
        onStop(function(){
          dbDisconnect(con_hub)
          dbDisconnect(con_lcg)
          dbDisconnect(con_quant)
        })
      },
      options = options, 
      enableBookmarking = enableBookmarking, 
      uiPattern = uiPattern
    ), 
    golem_opts = list(
      "con_hub" = con_hub,
      "con_lcg" = con_lcg,
      "con_quant" = con_quant
    )
  )
}
