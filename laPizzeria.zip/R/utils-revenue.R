loader_overview <- shiny::tagList(
  waiter::spin_1(),
  shiny::br(),
  "Loading data...",
  shiny::br(),
  "Be patient, calculation in progress!"
)
