library(testthat)
library(laPizzeria)

test_check("laPizzeria", reporter = JunitReporter$new(file = "test-result.xml"))
